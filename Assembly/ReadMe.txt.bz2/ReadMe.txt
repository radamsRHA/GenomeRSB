=========================================================================================
Subproject number:X202SC25011773
Project Name:TJ-US-UArk-Oebalus pugnax-Hi-C-WBI-Genome assembly-NVUS2024123011
Species Name:AG1_OP1
Delivery content:genome assembly result
Storage size:1.2G
=========================================================================================
*.fa							the genome assembly result
*.zip							the genome assembly report
md5.txt							md5sum file
checkSize.xls						size statistics of files
tree							list of files
=========================================================================================
